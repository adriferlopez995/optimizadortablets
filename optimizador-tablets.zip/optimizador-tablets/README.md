# Optimizador de tablets

App Android (Samsung / One UI, Android 12 o superior) que, con un toque:

1. **Analiza** la tablet: RAM, almacenamiento, batería, temperatura, ahorro de energía, animaciones, caché, apps sin usar y apps preinstaladas prescindibles.
2. **Mide** su rendimiento real (procesador, memoria, disco y fluidez de pantalla).
3. **Muestra sugerencias** ordenadas por impacto.
4. **Aplica** los cambios que puede hacer sola (si se le concede un permiso especial) y te guía en el resto.
5. **Vuelve a medir** y muestra el **porcentaje de mejora** antes/después.

No tiene IA en la tablet: usa reglas fijas y pruebas medibles. El botón **Compartir informe** genera un texto que se puede pegar en un asistente de IA para un análisis más profundo.

## 1. Compilar el APK (gratis, sin instalar nada)

1. Crea un repositorio **privado** en GitHub (la clave de firma interna va incluida).
2. Sube **todo el contenido de esta carpeta**, incluida la carpeta oculta `.github`.
   - Si la subida por web no incluye `.github`, crea el archivo a mano: *Add file > Create new file*, nombre `.github/workflows/build-apk.yml`, y pega el contenido de ese archivo.
3. Ve a la pestaña **Actions**. Se ejecuta «Compilar APK» (tarda 3–6 min). También puedes lanzarlo con *Run workflow*.
4. Al terminar, descarga `optimizador-tablets.apk` desde **Releases** (columna derecha del repositorio) o desde los *Artifacts* de la ejecución.
5. Si el flujo falla, abre el registro de la ejecución, copia el error y pásamelo.

## 2. Instalar en las tablets

1. Copia `optimizador-tablets.apk` al USB y conéctalo a la tablet (adaptador OTG / USB-C).
2. En **Mis archivos**, toca el APK. Permite «Instalar apps desconocidas» para Mis archivos cuando lo pida.
3. Si no deja instalar: desactiva **Auto Blocker** (Ajustes > Seguridad y privacidad > Auto Blocker). Si las tablets están gestionadas por el centro, puede que el administrador bloquee las fuentes desconocidas.
4. Las versiones nuevas se instalan encima de la anterior (misma firma), sin perder permisos.

## 3. Permisos

- **Acceso de uso** (sin PC): lo pide la propia app, pantalla *Configuración inicial*.
- **Permiso para aplicar cambios solo** (opcional, una vez por tablet, con PC y cable). Con la depuración USB activada:

```
adb shell pm grant org.centro.optimizador android.permission.WRITE_SECURE_SETTINGS
adb shell appops set org.centro.optimizador GET_USAGE_STATS allow
```

Sin este permiso, la app sigue funcionando: analiza, mide, sugiere y abre directamente cada ajuste para que lo cambies con un toque.

## Qué puede y qué no puede hacer una app normal

| Acción | Con permiso ADB | Sin permiso ADB |
|---|---|---|
| Bajar animaciones a 0,5× | Automático | Abre Opciones de desarrollador |
| Quitar ahorro de energía | Automático (puede fallar en algunos modelos) | Abre el ajuste |
| Desactivar «No mantener actividades» | Automático | Abre Opciones de desarrollador |
| Borrar cachés, liberar espacio | Te guía | Te guía |
| Desinstalar apps sin uso | Cuadro del sistema | Cuadro del sistema |
| Desactivar apps preinstaladas | Abre la ficha de la app | Abre la ficha de la app |
| Reiniciar | Manual | Manual |

Las apps de robótica y programación (Scratch, LEGO, mBlock, MakeCode, micro:bit, Arduino, Sphero, Ozobot, Tynker, etc.) **nunca se proponen para desinstalar**. En cualquier app propuesta puedes pulsar **Conservar**.

## Notas sobre la medición

- El porcentaje de mejora es la media geométrica de varias pruebas (procesador, memoria, escritura, fotogramas). Cada prueba se repite 3 veces y se usa la mediana.
- Hay un margen de error de ±5 %. Para comparar bien: tablet enchufada, fría, sin otras apps abiertas.
- Si la tablet tiene poca RAM, algunas mejoras serán limitadas: es una limitación del hardware y la app lo indica.

## Estructura

- `Diagnostics.kt`: lectura de datos del sistema.
- `Rules.kt`: reglas de recomendación y puntuación de «salud estimada».
- `Benchmark.kt`: pruebas de rendimiento.
- `Actions.kt`: cambios automáticos y accesos directos a Ajustes.
- `ui/Screens.kt`: pantallas (Jetpack Compose).
