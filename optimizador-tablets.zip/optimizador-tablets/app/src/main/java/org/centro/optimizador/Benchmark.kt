package org.centro.optimizador

import android.content.Context
import android.os.PowerManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import kotlin.concurrent.thread

data class FrameStats(val p95Ms: Double, val avgFps: Double, val jankPercent: Double)

/**
 * Pruebas cortas y repetibles para medir "antes y después":
 * procesador, memoria, escritura en disco y fluidez de pantalla (fotogramas).
 * Cada prueba se repite 3 veces y se usa la mediana para reducir el ruido.
 */
object Benchmark {

    @Volatile
    private var sink: Long = 0L

    private fun cpuWork(iterations: Int): Long {
        var x = 88172645463325252L
        var acc = 0L
        for (i in 0 until iterations) {
            x = x xor (x shl 13)
            x = x xor (x ushr 7)
            x = x xor (x shl 17)
            acc += (x and 0xFF) + Math.sqrt((i and 1023).toDouble()).toLong()
        }
        return acc
    }

    private fun memoryWork() {
        val a = IntArray(4_000_000)
        val b = IntArray(4_000_000)
        var s = 0L
        for (r in 0 until 10) {
            for (i in a.indices) a[i] = i * 31 + r
            System.arraycopy(a, 0, b, 0, a.size)
            var i = 0
            while (i < b.size) {
                s += b[i]
                i += 7
            }
        }
        sink = s
    }

    private fun timeMs(block: () -> Unit): Double {
        val t0 = System.nanoTime()
        block()
        return (System.nanoTime() - t0) / 1e6
    }

    private fun median(v: List<Double>): Double = v.sorted()[v.size / 2]

    private fun writeThroughput(dir: File): Double {
        val f = File(dir, "bench_big.tmp")
        val buf = ByteArray(1 shl 20) { (it * 7).toByte() }
        val t0 = System.nanoTime()
        FileOutputStream(f).use { out ->
            repeat(48) { out.write(buf) }
            out.fd.sync()
        }
        val sec = (System.nanoTime() - t0) / 1e9
        f.delete()
        return 48.0 / sec
    }

    private fun syncOpsPerSec(dir: File): Double {
        val f = File(dir, "bench_small.tmp")
        val buf = ByteArray(4096)
        val t0 = System.nanoTime()
        FileOutputStream(f).use { out ->
            repeat(150) {
                out.write(buf)
                out.fd.sync()
            }
        }
        val sec = (System.nanoTime() - t0) / 1e9
        f.delete()
        return 150.0 / sec
    }

    fun frameStats(stampsNanos: List<Long>, refreshHz: Float): FrameStats {
        if (stampsNanos.size < 12) return FrameStats(0.0, 0.0, 0.0)
        val intervals = ArrayList<Double>()
        for (i in 1 until stampsNanos.size) {
            intervals.add((stampsNanos[i] - stampsNanos[i - 1]) / 1e6)
        }
        val used = intervals.drop(5)
        val vsync = 1000.0 / refreshHz.coerceAtLeast(30f).toDouble()
        val sorted = used.sorted()
        val p95 = sorted[((sorted.size - 1) * 0.95).toInt()]
        val avg = used.average()
        val jank = used.count { it > vsync * 1.5 } * 100.0 / used.size
        return FrameStats(p95, 1000.0 / avg, jank)
    }

    suspend fun runAll(
        ctx: Context,
        setProgress: (String, Float) -> Unit,
        frameTest: suspend () -> FrameStats
    ): BenchResult {
        val dir = ctx.cacheDir

        setProgress("Calentando…", 0.02f)
        withContext(Dispatchers.Default) { sink = cpuWork(6_000_000) }

        setProgress("Midiendo el procesador (1 núcleo)…", 0.08f)
        val single = withContext(Dispatchers.Default) {
            median(List(3) { timeMs { sink = cpuWork(40_000_000) } })
        }

        setProgress("Midiendo el procesador (todos los núcleos)…", 0.22f)
        val cores = Runtime.getRuntime().availableProcessors().coerceIn(2, 8)
        val multi = withContext(Dispatchers.Default) {
            median(List(3) {
                timeMs {
                    val ts = List(cores) { thread { sink = cpuWork(15_000_000) } }
                    ts.forEach { it.join() }
                }
            })
        }

        setProgress("Midiendo la memoria…", 0.38f)
        val mem = withContext(Dispatchers.Default) { median(List(3) { timeMs { memoryWork() } }) }

        setProgress("Midiendo la velocidad de escritura…", 0.50f)
        val write = withContext(Dispatchers.IO) { median(List(3) { writeThroughput(dir) }) }

        setProgress("Midiendo escrituras pequeñas…", 0.65f)
        val sync = withContext(Dispatchers.IO) { median(List(3) { syncOpsPerSec(dir) }) }

        setProgress("Midiendo la fluidez de la pantalla (4 s)…", 0.75f)
        val frames = frameTest()

        setProgress("Terminando…", 0.97f)
        val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
        val thermal = pm.currentThermalStatus

        return BenchResult(
            cpuSingleMs = single,
            cpuMultiMs = multi,
            memoryMs = mem,
            writeMbps = write,
            syncOps = sync,
            frameP95Ms = frames.p95Ms,
            avgFps = frames.avgFps,
            jankPercent = frames.jankPercent,
            thermalStatus = thermal
        )
    }
}
