package org.centro.optimizador.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import org.centro.optimizador.Actions
import org.centro.optimizador.AppEntry
import org.centro.optimizador.BloatEntry
import org.centro.optimizador.Compare
import org.centro.optimizador.Finding
import org.centro.optimizador.Kind
import org.centro.optimizador.MainViewModel
import org.centro.optimizador.Metric
import org.centro.optimizador.RunData
import org.centro.optimizador.Screen
import org.centro.optimizador.Snapshot
import org.centro.optimizador.UiState
import org.centro.optimizador.f0
import org.centro.optimizador.f1
import java.text.DateFormat
import java.util.Date
import kotlin.math.cos
import kotlin.math.sin

private val Good = Color(0xFF15803D)
private val Warn = Color(0xFFB45309)
private val Bad = Color(0xFFB91C1C)

private fun scoreColor(score: Int): Color = when {
    score >= 80 -> Good
    score >= 55 -> Warn
    else -> Bad
}

@Composable
fun AppRoot(vm: MainViewModel) {
    val state by vm.state.collectAsStateWithLifecycle()

    BackHandler(enabled = state.screen != Screen.HOME && state.screen != Screen.RUNNING) {
        if (state.screen == Screen.SETUP) vm.backToReport() else vm.goHome()
    }

    Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Box(Modifier.fillMaxSize().safeDrawingPadding(), contentAlignment = Alignment.TopCenter) {
            Box(Modifier.fillMaxHeight().widthIn(max = 780.dp)) {
                when (state.screen) {
                    Screen.HOME -> HomeScreen(state, vm)
                    Screen.RUNNING -> RunningScreen(state, vm)
                    Screen.REPORT -> ReportScreen(state, vm)
                    Screen.COMPARE -> CompareScreen(state, vm)
                    Screen.SETUP -> SetupScreen(state, vm)
                }
            }
        }
    }
}

// ------------------------------------------------------------------ INICIO

@Composable
private fun HomeScreen(state: UiState, vm: MainViewModel) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("Optimizador de tablets", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text(
            "Analiza por qué va lenta esta tablet, te propone mejoras y, después de aplicarlas, mide cuánto ha mejorado.",
            style = MaterialTheme.typography.bodyLarge
        )

        state.error?.let { msg ->
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFFEE2E2)), modifier = Modifier.fillMaxWidth()) {
                Text(msg, Modifier.padding(16.dp), color = Bad)
            }
        }

        Button(onClick = { vm.startAnalysis() }, modifier = Modifier.fillMaxWidth().height(72.dp)) {
            Text("Analizar esta tablet", fontSize = 20.sp)
        }
        Text(
            "Tarda menos de un minuto. Conviene tenerla enchufada, sin otras apps abiertas y sin funda si está caliente.",
            style = MaterialTheme.typography.bodyMedium
        )

        state.baseline?.let { b ->
            Card(colors = CardDefaults.cardColors(containerColor = Color.White), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Análisis anterior", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                    Text("${fmtDate(b.timeMillis)} · salud estimada ${b.score}/100", style = MaterialTheme.typography.bodyMedium)
                    Text(
                        "Si ya aplicaste mejoras (o reiniciaste la tablet), mide de nuevo para ver el porcentaje de mejora.",
                        style = MaterialTheme.typography.bodySmall
                    )
                    Button(onClick = { vm.remeasure() }, modifier = Modifier.fillMaxWidth()) {
                        Text("Medir de nuevo y comparar")
                    }
                }
            }
        }

        OutlinedButton(onClick = { vm.openSetup() }, modifier = Modifier.fillMaxWidth()) {
            Text("Configuración inicial (permisos)")
        }
    }
}

// ------------------------------------------------------------------ MIDIENDO

@Composable
private fun RunningScreen(state: UiState, vm: MainViewModel) {
    val view = LocalView.current
    DisposableEffect(Unit) {
        view.keepScreenOn = true
        onDispose { view.keepScreenOn = false }
    }

    Column(
        Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(16.dp))
        Text("Analizando…", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        LinearProgressIndicator(progress = { state.progress }, modifier = Modifier.fillMaxWidth().height(10.dp))
        Text(state.progressText, style = MaterialTheme.typography.bodyLarge, textAlign = TextAlign.Center)
        Text(
            "No toques la pantalla ni abras otras apps hasta que termine.",
            style = MaterialTheme.typography.bodyMedium,
            textAlign = TextAlign.Center
        )

        if (state.frameTestActive) {
            val hz = view.display?.refreshRate ?: 60f
            FrameTestCanvas(
                Modifier.fillMaxWidth().height(260.dp).clip(RoundedCornerShape(16.dp)).background(Color(0xFF0F172A))
            )
            LaunchedEffect(Unit) {
                val stamps = ArrayList<Long>(512)
                val start = System.nanoTime()
                while (System.nanoTime() - start < 4_000_000_000L) {
                    withFrameNanos { stamps.add(it) }
                }
                vm.submitFrames(stamps, hz)
            }
        }
    }
}

/** Escena animada con carga gráfica moderada, sobre la que se miden los fotogramas. */
@Composable
private fun FrameTestCanvas(modifier: Modifier) {
    val transition = rememberInfiniteTransition(label = "frames")
    val phase = transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(2000, easing = LinearEasing), RepeatMode.Restart),
        label = "phase"
    )
    Canvas(modifier) {
        val t = phase.value
        val w = size.width
        val h = size.height
        for (i in 0 until 300) {
            val p = (t + i / 300f) % 1f
            val x = w * ((sin(p * 6.2832f * (1 + i % 3)) + 1f) / 2f)
            val y = h * ((cos(p * 6.2832f * (1 + i % 5)) + 1f) / 2f)
            drawCircle(
                color = Color.hsv((i * 7 % 360).toFloat(), 0.7f, 0.9f, 0.6f),
                radius = 14f + (i % 9) * 3f,
                center = Offset(x, y)
            )
        }
    }
}

// ------------------------------------------------------------------ INFORME

@Composable
private fun ReportScreen(state: UiState, vm: MainViewModel) {
    val ctx = LocalContext.current
    val snap = state.snapshot ?: return
    val hasAuto = state.findings.any { it.kind == Kind.AUTO }
    val score = org.centro.optimizador.Rules.score(state.findings)

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text("Resultado del análisis", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        }
        item { ScoreCard(score, snap, state.baseline) }

        if (state.autoResults.isNotEmpty()) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFECFDF5)), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("Cambios automáticos aplicados", fontWeight = FontWeight.SemiBold)
                        state.autoResults.forEach { Text(it, style = MaterialTheme.typography.bodyMedium) }
                    }
                }
            }
        }

        if (hasAuto) {
            item {
                Button(
                    onClick = { vm.applyAuto() },
                    enabled = !state.busy,
                    modifier = Modifier.fillMaxWidth().height(56.dp)
                ) { Text(if (state.busy) "Aplicando…" else "Aplicar mejoras automáticas", fontSize = 17.sp) }
            }
        } else if (!state.secureSettings) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFFEF3C7)), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            "Para que la app pueda aplicar cambios por sí sola, concede el permiso especial (una vez por tablet, con un PC).",
                            style = MaterialTheme.typography.bodyMedium
                        )
                        OutlinedButton(onClick = { vm.openSetup() }) { Text("Ver cómo hacerlo") }
                    }
                }
            }
        }

        if (state.findings.isEmpty()) {
            item { Text("No se han detectado problemas. ¡Buen estado!", style = MaterialTheme.typography.bodyLarge) }
        }
        items(state.findings, key = { it.id }) { f -> FindingCard(f, ctx) }

        if (snap.unusedApps.isNotEmpty()) {
            item { SectionTitle("Apps sin usar en 30 días") }
            items(snap.unusedApps, key = { "u_" + it.packageName }) { a ->
                UnusedRow(a, onUninstall = { Actions.uninstall(ctx, a.packageName) }, onKeep = { vm.keepApp(a.packageName) })
            }
        }
        if (snap.bloat.isNotEmpty()) {
            item { SectionTitle("Preinstaladas prescindibles") }
            items(snap.bloat, key = { "b_" + it.packageName }) { b ->
                BloatRow(b, onDisable = { Actions.appDetails(ctx, b.packageName) }, onKeep = { vm.keepApp(b.packageName) })
            }
        }

        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(onClick = { vm.remeasure() }, modifier = Modifier.fillMaxWidth().height(56.dp)) {
                    Text("Medir de nuevo y comparar", fontSize = 17.sp)
                }
                Text(
                    "Cuando hayas aplicado los cambios (reinicia la tablet si te lo pide), mide de nuevo para ver el porcentaje de mejora.",
                    style = MaterialTheme.typography.bodySmall
                )
                OutlinedButton(onClick = { Actions.share(ctx, vm.reportText()) }, modifier = Modifier.fillMaxWidth()) {
                    Text("Compartir informe")
                }
                TextButton(onClick = { vm.goHome() }, modifier = Modifier.fillMaxWidth()) { Text("Volver al inicio") }
            }
        }
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.SemiBold,
        modifier = Modifier.padding(top = 8.dp)
    )
}

@Composable
private fun ScoreCard(score: Int, snap: Snapshot, base: RunData?) {
    Card(colors = CardDefaults.cardColors(containerColor = Color.White), modifier = Modifier.fillMaxWidth()) {
        Row(
            Modifier.padding(20.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("$score", fontSize = 56.sp, fontWeight = FontWeight.Bold, color = scoreColor(score))
                Text("de 100", style = MaterialTheme.typography.bodySmall)
            }
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("Salud estimada", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Text("${snap.model} · ${snap.androidVersion}", style = MaterialTheme.typography.bodySmall)
                Text(
                    "RAM ${f1(snap.totalRamMb / 1024.0)} GB · Libre ${f1(snap.storageFreeGb)} de ${f1(snap.storageTotalGb)} GB",
                    style = MaterialTheme.typography.bodySmall
                )
                if (base != null) {
                    Text(
                        "Pantalla: ${f0(base.bench.avgFps)} fps · ${f0(base.bench.jankPercent)} % de fotogramas con tirones",
                        style = MaterialTheme.typography.bodySmall
                    )
                    if (base.bench.thermalStatus >= 2) {
                        Text(
                            "La tablet estaba caliente al medir: los resultados pueden salir peores.",
                            style = MaterialTheme.typography.bodySmall,
                            color = Warn
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun FindingCard(f: Finding, ctx: android.content.Context) {
    Card(colors = CardDefaults.cardColors(containerColor = Color.White), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(f.title, Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
                ImpactBadge(f.penalty)
            }
            Text(f.detail, style = MaterialTheme.typography.bodyMedium)
            if (f.kind == Kind.AUTO) {
                Text(
                    "Se aplica automáticamente con el botón de arriba.",
                    style = MaterialTheme.typography.bodySmall,
                    color = Good
                )
            }
            if (f.kind == Kind.GUIDED && f.actionLabel.isNotEmpty()) {
                OutlinedButton(onClick = { Actions.open(ctx, f.action) }) { Text(f.actionLabel) }
            }
            if (f.kind == Kind.MANUAL) {
                Text("Acción manual.", style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
private fun ImpactBadge(penalty: Int) {
    val (label, color) = when {
        penalty >= 7 -> "Impacto alto" to Bad
        penalty >= 4 -> "Impacto medio" to Warn
        penalty > 0 -> "Impacto bajo" to Color(0xFF475569)
        else -> "Información" to Color(0xFF475569)
    }
    Text(
        label,
        color = color,
        fontSize = 12.sp,
        fontWeight = FontWeight.SemiBold,
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(color.copy(alpha = 0.12f))
            .padding(horizontal = 10.dp, vertical = 4.dp)
    )
}

@Composable
private fun UnusedRow(a: AppEntry, onUninstall: () -> Unit, onKeep: () -> Unit) {
    val days = ((System.currentTimeMillis() - a.lastUsedMillis) / 86_400_000L).toInt()
    Card(colors = CardDefaults.cardColors(containerColor = Color.White), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(a.label, fontWeight = FontWeight.SemiBold)
            Text(
                "Ocupa ${a.sizeBytes / (1024 * 1024)} MB · sin usar desde hace $days días",
                style = MaterialTheme.typography.bodySmall
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = onKeep) { Text("Conservar") }
                Button(onClick = onUninstall) { Text("Desinstalar") }
            }
        }
    }
}

@Composable
private fun BloatRow(b: BloatEntry, onDisable: () -> Unit, onKeep: () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Color.White), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(b.label, fontWeight = FontWeight.SemiBold)
            Text(b.reason, style = MaterialTheme.typography.bodySmall)
            Text(
                "Pulsa «Desactivar» y, en la pantalla de la app, el botón Desactivar. Se puede volver a activar cuando quieras.",
                style = MaterialTheme.typography.bodySmall
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = onKeep) { Text("Conservar") }
                Button(onClick = onDisable) { Text("Desactivar") }
            }
        }
    }
}

// ------------------------------------------------------------------ COMPARACIÓN

@Composable
private fun CompareScreen(state: UiState, vm: MainViewModel) {
    val ctx = LocalContext.current
    val base = state.baseline
    val after = state.after
    if (base == null || after == null) {
        Column(Modifier.padding(24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("No hay una medición inicial con la que comparar.")
            Button(onClick = { vm.goHome() }) { Text("Volver al inicio") }
        }
        return
    }

    val metrics = Compare.metrics(base.bench, after.bench)
    val overall = Compare.overall(metrics)
    val (headline, color) = when {
        overall >= 5.0 -> "Mejora medida: +${f0(overall)} %" to Good
        overall <= -5.0 -> "Peor: ${f0(overall)} %" to Bad
        else -> "Sin cambio apreciable (${if (overall >= 0) "+" else ""}${f1(overall)} %)" to Warn
    }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item { Text("Antes y después", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold) }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Color.White), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(headline, fontSize = 30.sp, fontWeight = FontWeight.Bold, color = color)
                    Text(
                        "Salud estimada: ${base.score} → ${after.score} de 100",
                        style = MaterialTheme.typography.titleMedium
                    )
                    if (overall <= -5.0) {
                        Text(
                            "Si sale peor, suele deberse a que la tablet está caliente, con poca batería o con otras apps abiertas. Reinicia, deja enfriar y vuelve a medir.",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Color.White), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Row(Modifier.fillMaxWidth()) {
                        Text("Prueba", Modifier.weight(1.6f), fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                        Text("Antes", Modifier.weight(1f), fontWeight = FontWeight.SemiBold, fontSize = 13.sp, textAlign = TextAlign.End)
                        Text("Después", Modifier.weight(1f), fontWeight = FontWeight.SemiBold, fontSize = 13.sp, textAlign = TextAlign.End)
                        Text("Cambio", Modifier.weight(1f), fontWeight = FontWeight.SemiBold, fontSize = 13.sp, textAlign = TextAlign.End)
                    }
                    HorizontalDivider(Modifier.padding(vertical = 6.dp))
                    metrics.forEach { MetricRow(it) }
                }
            }
        }
        item {
            Text(
                "Las mediciones varían un poco entre pruebas (aprox. ±5 %). Para comparar bien: tablet enchufada, fría y sin otras apps abiertas.",
                style = MaterialTheme.typography.bodySmall
            )
        }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(onClick = { Actions.share(ctx, vm.reportText()) }, modifier = Modifier.fillMaxWidth()) {
                    Text("Compartir informe")
                }
                OutlinedButton(onClick = { vm.backToReport() }, modifier = Modifier.fillMaxWidth()) {
                    Text("Ver sugerencias pendientes")
                }
                TextButton(onClick = { vm.goHome() }, modifier = Modifier.fillMaxWidth()) { Text("Volver al inicio") }
            }
        }
    }
}

@Composable
private fun MetricRow(m: Metric) {
    val change = if (m.valid) (if (m.changePercent >= 0) "+" else "") + f0(m.changePercent) + " %" else "—"
    val changeColor = when {
        !m.valid -> Color(0xFF475569)
        m.changePercent >= 5.0 -> Good
        m.changePercent <= -5.0 -> Bad
        else -> Color(0xFF475569)
    }
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(m.name, Modifier.weight(1.6f), fontSize = 14.sp)
        Text(fmtMetric(m.before) + " " + m.unit, Modifier.weight(1f), fontSize = 13.sp, textAlign = TextAlign.End)
        Text(fmtMetric(m.after) + " " + m.unit, Modifier.weight(1f), fontSize = 13.sp, textAlign = TextAlign.End)
        Text(change, Modifier.weight(1f), fontSize = 14.sp, fontWeight = FontWeight.Bold, color = changeColor, textAlign = TextAlign.End)
    }
}

private fun fmtMetric(v: Double): String = if (v >= 100.0) f0(v) else f1(v)

private fun fmtDate(ms: Long): String =
    DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT).format(Date(ms))

// ------------------------------------------------------------------ CONFIGURACIÓN INICIAL

@Composable
private fun SetupScreen(state: UiState, vm: MainViewModel) {
    val ctx = LocalContext.current
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("Configuración inicial", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)

        PermissionCard(
            title = "1. Acceso de uso",
            ok = state.usageAccess,
            text = "Permite ver qué apps no se usan y cuánto ocupa cada una. Se concede en Ajustes sin necesidad de PC."
        ) {
            if (!state.usageAccess) {
                Button(onClick = { Actions.open(ctx, org.centro.optimizador.ActionType.USAGE_ACCESS) }) {
                    Text("Abrir ajustes de acceso de uso")
                }
            }
        }

        PermissionCard(
            title = "2. Permiso para aplicar cambios solo (opcional)",
            ok = state.secureSettings,
            text = "Con él, la app puede bajar las animaciones, quitar el ahorro de energía y otros ajustes con un toque. " +
                "Android solo permite concederlo por ADB: se hace una vez por tablet, con un PC y un cable USB."
        ) {
            if (!state.secureSettings) {
                Text("En la tablet: Ajustes > Acerca de la tablet > Información de software > pulsa 7 veces «Número de compilación»; " +
                    "luego Ajustes > Opciones de desarrollador > activa «Depuración USB».", style = MaterialTheme.typography.bodySmall)
                Text("En el PC, con la tablet conectada, ejecuta:", style = MaterialTheme.typography.bodySmall)
                CommandBox("adb shell pm grant ${state.pkgName} android.permission.WRITE_SECURE_SETTINGS")
                CommandBox("adb shell appops set ${state.pkgName} GET_USAGE_STATS allow")
                Text("Después, vuelve a esta pantalla: el estado se actualiza solo.", style = MaterialTheme.typography.bodySmall)
            }
        }

        OutlinedButton(onClick = { vm.backToReport() }, modifier = Modifier.fillMaxWidth()) { Text("Volver") }
    }
}

@Composable
private fun PermissionCard(title: String, ok: Boolean, text: String, content: @Composable () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Color.White), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(title, Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
                Text(
                    if (ok) "✔ Concedido" else "Pendiente",
                    color = if (ok) Good else Warn,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 13.sp
                )
            }
            Text(text, style = MaterialTheme.typography.bodyMedium)
            content()
        }
    }
}

@Composable
private fun CommandBox(cmd: String) {
    val clip = LocalClipboardManager.current
    Surface(color = Color(0xFF1F2937), shape = RoundedCornerShape(10.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp)) {
            Text(cmd, color = Color.White, fontFamily = FontFamily.Monospace, fontSize = 13.sp)
            TextButton(onClick = { clip.setText(AnnotatedString(cmd)) }) {
                Text("Copiar", color = Color(0xFF99F6E4))
            }
        }
    }
}
