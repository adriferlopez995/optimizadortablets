package org.centro.optimizador

import org.json.JSONObject
import java.util.Locale
import kotlin.math.exp
import kotlin.math.ln

fun f1(x: Double): String = String.format(Locale.getDefault(), "%.1f", x)
fun f1(x: Float): String = f1(x.toDouble())
fun f0(x: Double): String = String.format(Locale.getDefault(), "%.0f", x)

data class AppEntry(
    val packageName: String,
    val label: String,
    val sizeBytes: Long,
    val lastUsedMillis: Long
)

data class BloatEntry(
    val packageName: String,
    val label: String,
    val reason: String
)

data class Snapshot(
    val takenAt: Long,
    val model: String,
    val androidVersion: String,
    val securityPatch: String,
    val totalRamMb: Long,
    val availRamMb: Long,
    val storageTotalGb: Double,
    val storageFreeGb: Double,
    val batteryPercent: Int,
    val batteryTempC: Double,
    val batteryHealthGood: Boolean,
    val cycleCount: Int,
    val powerSaver: Boolean,
    val thermalStatus: Int,
    val uptimeDays: Double,
    val animationScale: Float,
    val dontKeepActivities: Boolean,
    val userAppCount: Int,
    val usageAccess: Boolean,
    val secureSettings: Boolean,
    val totalCacheMb: Long,
    val bigApps: List<AppEntry>,
    val unusedApps: List<AppEntry>,
    val bloat: List<BloatEntry>
) {
    val storageFreePercent: Double
        get() = if (storageTotalGb > 0) storageFreeGb / storageTotalGb * 100.0 else 100.0
}

data class BenchResult(
    val cpuSingleMs: Double,
    val cpuMultiMs: Double,
    val memoryMs: Double,
    val writeMbps: Double,
    val syncOps: Double,
    val frameP95Ms: Double,
    val avgFps: Double,
    val jankPercent: Double,
    val thermalStatus: Int
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("cpuSingleMs", cpuSingleMs)
        put("cpuMultiMs", cpuMultiMs)
        put("memoryMs", memoryMs)
        put("writeMbps", writeMbps)
        put("syncOps", syncOps)
        put("frameP95Ms", frameP95Ms)
        put("avgFps", avgFps)
        put("jankPercent", jankPercent)
        put("thermalStatus", thermalStatus)
    }

    companion object {
        fun fromJson(o: JSONObject) = BenchResult(
            o.getDouble("cpuSingleMs"),
            o.getDouble("cpuMultiMs"),
            o.getDouble("memoryMs"),
            o.getDouble("writeMbps"),
            o.getDouble("syncOps"),
            o.getDouble("frameP95Ms"),
            o.getDouble("avgFps"),
            o.getDouble("jankPercent"),
            o.getInt("thermalStatus")
        )
    }
}

data class RunData(
    val bench: BenchResult,
    val score: Int,
    val timeMillis: Long
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("bench", bench.toJson())
        put("score", score)
        put("time", timeMillis)
    }

    companion object {
        fun fromJson(o: JSONObject) = RunData(
            BenchResult.fromJson(o.getJSONObject("bench")),
            o.getInt("score"),
            o.getLong("time")
        )
    }
}

data class Metric(
    val name: String,
    val unit: String,
    val before: Double,
    val after: Double,
    val higherIsBetter: Boolean,
    val counts: Boolean = true
) {
    val valid: Boolean get() = before > 0.0 && after > 0.0

    /** Mayor que 1 = mejora. */
    val ratio: Double
        get() = when {
            !valid -> 1.0
            higherIsBetter -> after / before
            else -> before / after
        }

    val changePercent: Double get() = (ratio - 1.0) * 100.0
}

object Compare {
    fun metrics(a: BenchResult, b: BenchResult): List<Metric> = listOf(
        Metric("Procesador (1 núcleo)", "ms", a.cpuSingleMs, b.cpuSingleMs, false),
        Metric("Procesador (todos los núcleos)", "ms", a.cpuMultiMs, b.cpuMultiMs, false),
        Metric("Memoria RAM", "ms", a.memoryMs, b.memoryMs, false),
        Metric("Escritura grande", "MB/s", a.writeMbps, b.writeMbps, true),
        Metric("Escrituras pequeñas", "ops/s", a.syncOps, b.syncOps, true),
        Metric("Fotograma lento (p95)", "ms", a.frameP95Ms, b.frameP95Ms, false),
        Metric("Fotogramas por segundo", "fps", a.avgFps, b.avgFps, true, counts = false),
        Metric("Fotogramas con tirones", "%", a.jankPercent, b.jankPercent, false, counts = false)
    )

    /** Media geométrica de las mejoras de las métricas que cuentan, en %. */
    fun overall(ms: List<Metric>): Double {
        val c = ms.filter { it.counts && it.valid }
        if (c.isEmpty()) return 0.0
        val g = exp(c.map { ln(it.ratio) }.average())
        return (g - 1.0) * 100.0
    }
}
