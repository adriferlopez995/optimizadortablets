package org.centro.optimizador.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    val colors = lightColorScheme(
        primary = Color(0xFF0F766E),
        onPrimary = Color.White,
        primaryContainer = Color(0xFFCCFBF1),
        onPrimaryContainer = Color(0xFF042F2E),
        secondary = Color(0xFF475569),
        background = Color(0xFFF5F5F4),
        surface = Color(0xFFFAFAF9),
        error = Color(0xFFB91C1C)
    )
    MaterialTheme(colorScheme = colors, content = content)
}
