package org.centro.optimizador

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.storage.StorageManager
import android.provider.Settings

object Actions {

    private fun start(ctx: Context, intent: Intent, fallback: Intent? = null) {
        try {
            ctx.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
            if (fallback != null) {
                try {
                    ctx.startActivity(fallback.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                } catch (e2: Exception) {
                    // Sin pantalla de ajustes disponible; no se puede hacer más.
                }
            }
        }
    }

    fun open(ctx: Context, type: ActionType) {
        val intent = when (type) {
            ActionType.STORAGE -> Intent(Settings.ACTION_INTERNAL_STORAGE_SETTINGS)
            ActionType.CLEAR_CACHE -> Intent(StorageManager.ACTION_CLEAR_APP_CACHE)
            ActionType.DEV_SETTINGS -> Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS)
            ActionType.BATTERY_SAVER -> Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS)
            ActionType.USAGE_ACCESS -> Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)
            ActionType.DEVICE_INFO -> Intent(Settings.ACTION_DEVICE_INFO_SETTINGS)
            ActionType.NONE -> return
        }
        val fallback = if (type == ActionType.CLEAR_CACHE) {
            Intent(Settings.ACTION_INTERNAL_STORAGE_SETTINGS)
        } else {
            Intent(Settings.ACTION_SETTINGS)
        }
        start(ctx, intent, fallback)
    }

    fun uninstall(ctx: Context, pkg: String) =
        start(ctx, Intent(Intent.ACTION_DELETE, Uri.parse("package:$pkg")))

    fun appDetails(ctx: Context, pkg: String) =
        start(ctx, Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg")))

    fun share(ctx: Context, text: String) {
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, "Informe de la tablet")
            putExtra(Intent.EXTRA_TEXT, text)
        }
        start(ctx, Intent.createChooser(send, "Compartir informe"))
    }

    /**
     * Aplica los cambios automáticos. Solo funciona si la app tiene WRITE_SECURE_SETTINGS
     * (se concede una vez por tablet con ADB). Devuelve, por cada cambio, si la escritura tuvo éxito.
     */
    fun applyAuto(ctx: Context, ids: List<String>): Map<String, Boolean> {
        val cr = ctx.contentResolver
        val out = LinkedHashMap<String, Boolean>()
        for (id in ids) {
            out[id] = try {
                when (id) {
                    "anim" -> {
                        listOf(
                            "window_animation_scale",
                            "transition_animation_scale",
                            "animator_duration_scale"
                        ).forEach { Settings.Global.putFloat(cr, it, 0.5f) }
                        true
                    }
                    "powersaver" -> Settings.Global.putInt(cr, "low_power", 0)
                    "dontkeep" -> Settings.Global.putInt(cr, "always_finish_activities", 0)
                    else -> false
                }
            } catch (e: Exception) {
                false
            }
        }
        return out
    }
}
