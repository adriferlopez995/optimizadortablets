package org.centro.optimizador

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONObject

enum class Screen { HOME, RUNNING, REPORT, COMPARE, SETUP }

data class UiState(
    val screen: Screen = Screen.HOME,
    val progress: Float = 0f,
    val progressText: String = "",
    val frameTestActive: Boolean = false,
    val snapshot: Snapshot? = null,
    val findings: List<Finding> = emptyList(),
    val baseline: RunData? = null,
    val after: RunData? = null,
    val autoResults: List<String> = emptyList(),
    val protectedPkgs: Set<String> = emptySet(),
    val usageAccess: Boolean = false,
    val secureSettings: Boolean = false,
    val pkgName: String = "",
    val busy: Boolean = false,
    val error: String? = null
)

class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val ctx: Context get() = getApplication<Application>()
    private val prefs = app.getSharedPreferences("optimizador", Context.MODE_PRIVATE)

    private val _state = MutableStateFlow(
        UiState(
            baseline = loadRun("baseline"),
            protectedPkgs = (prefs.getStringSet("protected", emptySet()) ?: emptySet()).toSet(),
            pkgName = app.packageName
        )
    )
    val state: StateFlow<UiState> = _state.asStateFlow()

    private var frameDeferred: CompletableDeferred<FrameStats>? = null

    // ---------- Persistencia ----------

    private fun saveRun(key: String, run: RunData) {
        prefs.edit().putString(key, run.toJson().toString()).apply()
    }

    private fun loadRun(key: String): RunData? {
        val raw = prefs.getString(key, null) ?: return null
        return try {
            RunData.fromJson(JSONObject(raw))
        } catch (e: Exception) {
            null
        }
    }

    // ---------- Navegación ----------

    fun goHome() = _state.update { it.copy(screen = Screen.HOME, error = null) }

    fun openSetup() {
        refreshPermissions()
        _state.update { it.copy(screen = Screen.SETUP) }
    }

    fun backToReport() {
        if (_state.value.snapshot != null) _state.update { it.copy(screen = Screen.REPORT) } else goHome()
    }

    fun onResume() {
        refreshPermissions()
        val s = _state.value
        if (s.screen == Screen.REPORT && !s.busy && s.snapshot != null) refreshSnapshot()
    }

    private fun refreshPermissions() {
        val c = ctx
        _state.update {
            it.copy(
                usageAccess = Diagnostics.hasUsageAccess(c),
                secureSettings = Diagnostics.hasSecureSettings(c),
                pkgName = c.packageName
            )
        }
    }

    // ---------- Pruebas de rendimiento ----------

    private suspend fun runBench(): BenchResult = Benchmark.runAll(
        ctx,
        setProgress = { text, p -> _state.update { it.copy(progressText = text, progress = p) } },
        frameTest = {
            val d = CompletableDeferred<FrameStats>()
            frameDeferred = d
            _state.update { it.copy(frameTestActive = true) }
            try {
                withTimeoutOrNull(30_000L) { d.await() } ?: FrameStats(0.0, 0.0, 0.0)
            } finally {
                _state.update { it.copy(frameTestActive = false) }
            }
        }
    )

    fun submitFrames(stamps: List<Long>, refreshHz: Float) {
        frameDeferred?.complete(Benchmark.frameStats(stamps, refreshHz))
    }

    // ---------- Flujo principal ----------

    /** 1) Mide el estado actual y las prestaciones, y muestra las sugerencias. */
    fun startAnalysis() {
        if (_state.value.screen == Screen.RUNNING) return
        _state.update {
            it.copy(
                screen = Screen.RUNNING, progress = 0f, progressText = "Leyendo datos de la tablet…",
                error = null, after = null, autoResults = emptyList()
            )
        }
        viewModelScope.launch(Dispatchers.Default) {
            try {
                val snap = withContext(Dispatchers.IO) { Diagnostics.collect(ctx, _state.value.protectedPkgs) }
                val findings = Rules.evaluate(snap)
                val bench = runBench()
                val run = RunData(bench, Rules.score(findings), System.currentTimeMillis())
                saveRun("baseline", run)
                _state.update {
                    it.copy(
                        screen = Screen.REPORT, snapshot = snap, findings = findings,
                        baseline = run, after = null
                    )
                }
            } catch (e: Exception) {
                _state.update { it.copy(screen = Screen.HOME, error = "No se pudo completar el análisis: ${e.message}") }
            }
        }
    }

    /** 2) Aplica los cambios que se pueden hacer solos (requiere el permiso concedido por ADB). */
    fun applyAuto() {
        val s = _state.value
        val ids = s.findings.filter { it.kind == Kind.AUTO }.map { it.id }
        if (ids.isEmpty() || s.busy) return
        _state.update { it.copy(busy = true) }
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val written = Actions.applyAuto(ctx, ids)
                delay(1200)
                val snap = Diagnostics.collect(ctx, _state.value.protectedPkgs)
                val findings = Rules.evaluate(snap)
                val messages = written.map { (id, ok) ->
                    val name = when (id) {
                        "anim" -> "Animaciones a 0,5×"
                        "powersaver" -> "Ahorro de energía desactivado"
                        "dontkeep" -> "«No mantener actividades» desactivado"
                        else -> id
                    }
                    val reallyOk = ok && !(id == "powersaver" && snap.powerSaver)
                    if (reallyOk) "✔ $name" else "✖ No se pudo aplicar: $name (hazlo a mano desde Ajustes)"
                }
                _state.update { it.copy(snapshot = snap, findings = findings, autoResults = messages, busy = false) }
            } catch (e: Exception) {
                _state.update { it.copy(busy = false, error = "Error al aplicar cambios: ${e.message}") }
            }
        }
    }

    /** 3) Vuelve a medir y compara con la medición inicial. */
    fun remeasure() {
        if (_state.value.screen == Screen.RUNNING) return
        _state.update {
            it.copy(screen = Screen.RUNNING, progress = 0f, progressText = "Leyendo datos de la tablet…", error = null)
        }
        viewModelScope.launch(Dispatchers.Default) {
            try {
                val snap = withContext(Dispatchers.IO) { Diagnostics.collect(ctx, _state.value.protectedPkgs) }
                val findings = Rules.evaluate(snap)
                val bench = runBench()
                val run = RunData(bench, Rules.score(findings), System.currentTimeMillis())
                _state.update {
                    it.copy(screen = Screen.COMPARE, snapshot = snap, findings = findings, after = run)
                }
            } catch (e: Exception) {
                _state.update { it.copy(screen = Screen.HOME, error = "No se pudo completar la medición: ${e.message}") }
            }
        }
    }

    /** Refresca la lista de problemas (p. ej. al volver de Ajustes tras desinstalar algo). */
    fun refreshSnapshot() {
        if (_state.value.busy) return
        _state.update { it.copy(busy = true) }
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val snap = Diagnostics.collect(ctx, _state.value.protectedPkgs)
                val findings = Rules.evaluate(snap)
                _state.update { it.copy(snapshot = snap, findings = findings, busy = false) }
            } catch (e: Exception) {
                _state.update { it.copy(busy = false) }
            }
        }
    }

    /** Marca una app como "conservar": no se volverá a proponer. */
    fun keepApp(pkg: String) {
        val newSet = _state.value.protectedPkgs + pkg
        prefs.edit().putStringSet("protected", newSet).apply()
        val snap = _state.value.snapshot
        if (snap == null) {
            _state.update { it.copy(protectedPkgs = newSet) }
            return
        }
        val updated = snap.copy(
            unusedApps = snap.unusedApps.filter { it.packageName != pkg },
            bloat = snap.bloat.filter { it.packageName != pkg }
        )
        _state.update { it.copy(protectedPkgs = newSet, snapshot = updated, findings = Rules.evaluate(updated)) }
    }

    fun reportText(): String {
        val s = _state.value
        return Report.build(s.snapshot, s.findings, s.baseline, s.after)
    }
}
