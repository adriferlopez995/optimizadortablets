package org.centro.optimizador

import java.time.LocalDate
import java.time.temporal.ChronoUnit

enum class Kind { AUTO, GUIDED, MANUAL }

enum class ActionType {
    NONE, STORAGE, CLEAR_CACHE, DEV_SETTINGS, BATTERY_SAVER, USAGE_ACCESS, DEVICE_INFO
}

data class Finding(
    val id: String,
    val title: String,
    val detail: String,
    /** Puntos que resta a la "salud estimada" (0 = solo informativo). */
    val penalty: Int,
    val kind: Kind,
    val action: ActionType = ActionType.NONE,
    val actionLabel: String = ""
)

/**
 * Motor de reglas transparente: convierte los datos medidos en recomendaciones ordenadas por impacto.
 * No hay IA en la tablet; el informe se puede compartir para que lo interprete una persona o un asistente.
 */
object Rules {

    fun evaluate(s: Snapshot): List<Finding> {
        val out = ArrayList<Finding>()
        val autoOrGuided = if (s.secureSettings) Kind.AUTO else Kind.GUIDED

        if (s.animationScale > 0.55f) {
            out += Finding(
                id = "anim",
                title = "Animaciones del sistema lentas (${f1(s.animationScale)}×)",
                detail = "Bajarlas a 0,5× hace que menús, cambios de app y ventanas se sientan bastante más ágiles." +
                    if (s.secureSettings) "" else " En Ajustes > Opciones de desarrollador, pon las tres escalas de animación en 0,5x.",
                penalty = 4,
                kind = autoOrGuided,
                action = ActionType.DEV_SETTINGS,
                actionLabel = "Abrir opciones de desarrollador"
            )
        }

        if (s.powerSaver) {
            out += Finding(
                id = "powersaver",
                title = "Ahorro de energía activado",
                detail = "Limita la velocidad del procesador y de las animaciones. Desactívalo mientras se usen las tablets en clase.",
                penalty = 8,
                kind = autoOrGuided,
                action = ActionType.BATTERY_SAVER,
                actionLabel = "Abrir ahorro de batería"
            )
        }

        if (s.dontKeepActivities) {
            out += Finding(
                id = "dontkeep",
                title = "Activada la opción «No mantener actividades»",
                detail = "Es un ajuste de desarrollador que cierra cada pantalla al salir de ella: las apps tardan mucho más en volver.",
                penalty = 6,
                kind = autoOrGuided,
                action = ActionType.DEV_SETTINGS,
                actionLabel = "Abrir opciones de desarrollador"
            )
        }

        val free = s.storageFreePercent
        if (free < 20.0) {
            val p = when {
                free < 10.0 -> 9
                free < 15.0 -> 7
                else -> 4
            }
            out += Finding(
                id = "storage",
                title = "Almacenamiento casi lleno (${f1(s.storageFreeGb)} GB libres de ${f1(s.storageTotalGb)} GB)",
                detail = "Con poco espacio libre Android se vuelve mucho más lento (escritura, instalación, apps). " +
                    "Intenta dejar al menos un 20 % libre: borra vídeos, descargas y apps que no se usen.",
                penalty = p,
                kind = Kind.GUIDED,
                action = ActionType.STORAGE,
                actionLabel = "Abrir almacenamiento"
            )
        }

        if (s.totalCacheMb >= 1000) {
            out += Finding(
                id = "cache",
                title = "${s.totalCacheMb} MB de caché de apps",
                detail = "Borrarla libera espacio, pero por sí sola acelera poco. Útil si además falta espacio.",
                penalty = 3,
                kind = Kind.GUIDED,
                action = ActionType.CLEAR_CACHE,
                actionLabel = "Borrar cachés"
            )
        }

        if (s.uptimeDays >= 5.0) {
            out += Finding(
                id = "reboot",
                title = "Lleva ${f1(s.uptimeDays)} días sin reiniciarse",
                detail = "Reiniciar libera memoria y procesos acumulados; en tablets de clase suele notarse bastante. Mantén pulsado el botón de encendido y pulsa Reiniciar.",
                penalty = 6,
                kind = Kind.MANUAL
            )
        }

        if (s.thermalStatus >= 2 || s.batteryTempC >= 42.0) {
            out += Finding(
                id = "thermal",
                title = "Tablet caliente (${f1(s.batteryTempC)} °C)",
                detail = "Al calentarse, el sistema reduce la velocidad. Déjala enfriar, sin funda ni sol directo, y vuelve a medir.",
                penalty = 5,
                kind = Kind.MANUAL
            )
        }

        if (!s.batteryHealthGood || s.cycleCount >= 800) {
            out += Finding(
                id = "battery",
                title = "Batería muy gastada",
                detail = "Una batería degradada puede provocar bajadas de rendimiento y apagados. Considera sustituirla si el problema persiste.",
                penalty = 3,
                kind = Kind.MANUAL
            )
        }

        val patch = try {
            LocalDate.parse(s.securityPatch)
        } catch (e: Exception) {
            null
        }
        if (patch != null && ChronoUnit.DAYS.between(patch, LocalDate.now()) > 365) {
            out += Finding(
                id = "patch",
                title = "Parche de seguridad antiguo (${s.securityPatch})",
                detail = "Busca actualizaciones en Ajustes > Actualización de software. Las versiones nuevas suelen mejorar rendimiento y estabilidad.",
                penalty = 2,
                kind = Kind.GUIDED,
                action = ActionType.DEVICE_INFO,
                actionLabel = "Abrir ajustes"
            )
        }

        if (s.totalRamMb in 1..3300) {
            out += Finding(
                id = "ram",
                title = "Poca memoria RAM (${f1(s.totalRamMb / 1024.0)} GB)",
                detail = "Es una limitación del hardware: con las apps de programación abiertas conviene cerrar las demás. " +
                    "Esta tablet no será tan fluida como una con más RAM, aunque se optimice.",
                penalty = 0,
                kind = Kind.MANUAL
            )
        }

        if (!s.usageAccess) {
            out += Finding(
                id = "usage",
                title = "Falta el permiso «Acceso de uso»",
                detail = "Sin él no puedo ver qué apps no se usan ni cuánto ocupa cada una.",
                penalty = 0,
                kind = Kind.GUIDED,
                action = ActionType.USAGE_ACCESS,
                actionLabel = "Dar acceso de uso"
            )
        } else if (s.unusedApps.isNotEmpty()) {
            val n = s.unusedApps.size
            out += Finding(
                id = "unused",
                title = "$n apps sin usar en 30 días",
                detail = "Ocupan espacio y pueden ejecutar procesos en segundo plano. Aparecen más abajo; las de robótica y programación están protegidas.",
                penalty = minOf(6, n),
                kind = Kind.GUIDED
            )
        }

        if (s.bloat.isNotEmpty()) {
            val n = s.bloat.size
            out += Finding(
                id = "bloat",
                title = "$n apps preinstaladas prescindibles",
                detail = "Son apps del fabricante o de terceros que suelen consumir memoria en segundo plano. Se pueden volver a activar en cualquier momento.",
                penalty = minOf(6, 2 * n),
                kind = Kind.GUIDED
            )
        }

        return out.sortedWith(compareByDescending<Finding> { it.penalty }.thenBy { it.title })
    }

    fun score(findings: List<Finding>): Int = (100 - findings.sumOf { it.penalty }).coerceIn(0, 100)
}
