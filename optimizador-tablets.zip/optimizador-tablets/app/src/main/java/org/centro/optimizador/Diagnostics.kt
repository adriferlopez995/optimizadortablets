package org.centro.optimizador

import android.app.ActivityManager
import android.app.AppOpsManager
import android.app.usage.StorageStatsManager
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.PowerManager
import android.os.Process
import android.os.StatFs
import android.os.SystemClock
import android.os.storage.StorageManager
import android.provider.Settings

object Diagnostics {

    private const val MB = 1024L * 1024L
    private const val DAY = 24L * 60L * 60L * 1000L

    /** Apps que casi nunca hacen falta en una tablet de clase (solo se avisa si están instaladas y activas). */
    private val BLOAT = listOf(
        Triple("com.samsung.android.bixby.agent", "Bixby", "Asistente de voz; mantiene servicios en segundo plano."),
        Triple("com.samsung.android.bixby.wakeup", "Bixby (activación por voz)", "Escucha en segundo plano."),
        Triple("com.samsung.android.app.spage", "Samsung Free", "Pantalla de noticias; consume memoria y datos."),
        Triple("com.samsung.android.game.gamehome", "Game Launcher", "Lanzador de juegos de Samsung."),
        Triple("com.samsung.android.game.gametools", "Game Tools", "Superposición de juegos en segundo plano."),
        Triple("com.samsung.android.arzone", "AR Zone", "Realidad aumentada; rara vez se usa."),
        Triple("com.samsung.android.ardrawing", "AR Doodle", "Realidad aumentada; rara vez se usa."),
        Triple("com.samsung.android.app.tips", "Consejos de Samsung", "Servicio de tutoriales."),
        Triple("com.facebook.katana", "Facebook", "Preinstalada; no se usa en clase."),
        Triple("com.facebook.appmanager", "Facebook App Manager", "Servicio en segundo plano."),
        Triple("com.facebook.services", "Facebook Services", "Servicio en segundo plano."),
        Triple("com.facebook.system", "Facebook System", "Servicio en segundo plano."),
        Triple("com.netflix.mediaclient", "Netflix", "Preinstalada; no se usa en clase."),
        Triple("com.netflix.partner.activation", "Netflix (activación)", "Servicio de activación."),
        Triple("com.microsoft.office.officehubrow", "Microsoft 365 (Office)", "Preinstalada; pesada."),
        Triple("com.linkedin.android", "LinkedIn", "Preinstalada; no se usa en clase."),
        Triple("com.spotify.music", "Spotify", "Preinstalada; no se usa en clase.")
    )

    /** Si el nombre o el paquete contiene una de estas palabras, nunca se propone eliminar la app. */
    private val PROTECTED_KEYWORDS = listOf(
        "scratch", "lego", "mblock", "makecode", "microbit", "micro:bit", "arduino", "sphero",
        "ozobot", "beebot", "bee-bot", "tynker", "code.org", "blockly", "thunkable", "wedo",
        "spike", "robot", "cubetto", "ev3", "mindstorms", "makeblock", "kodable", "codey",
        "edison", "programa", "coding"
    )

    fun isProtected(pkg: String, label: String, userProtected: Set<String>): Boolean {
        if (userProtected.contains(pkg)) return true
        val p = pkg.lowercase()
        val l = label.lowercase()
        return PROTECTED_KEYWORDS.any { p.contains(it) || l.contains(it) }
    }

    fun hasUsageAccess(ctx: Context): Boolean {
        val ops = ctx.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = ops.unsafeCheckOpNoThrow(
            AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName
        )
        return mode == AppOpsManager.MODE_ALLOWED
    }

    fun hasSecureSettings(ctx: Context): Boolean =
        ctx.checkSelfPermission("android.permission.WRITE_SECURE_SETTINGS") == PackageManager.PERMISSION_GRANTED

    @Suppress("DEPRECATION")
    fun collect(ctx: Context, userProtected: Set<String>): Snapshot {
        val now = System.currentTimeMillis()
        val pm = ctx.packageManager
        val cr = ctx.contentResolver

        // Memoria
        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)

        // Almacenamiento
        val stat = StatFs(Environment.getDataDirectory().path)
        val totalGb = stat.totalBytes / (1024.0 * MB)
        val freeGb = stat.availableBytes / (1024.0 * MB)

        // Batería
        val bat = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = bat?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = bat?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val pct = if (level >= 0 && scale > 0) level * 100 / scale else -1
        val temp = (bat?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10.0
        val health = bat?.getIntExtra(BatteryManager.EXTRA_HEALTH, BatteryManager.BATTERY_HEALTH_UNKNOWN)
            ?: BatteryManager.BATTERY_HEALTH_UNKNOWN
        val healthGood = health == BatteryManager.BATTERY_HEALTH_GOOD || health == BatteryManager.BATTERY_HEALTH_UNKNOWN
        val cycles = bat?.getIntExtra(BatteryManager.EXTRA_CYCLE_COUNT, -1) ?: -1

        // Energía y temperatura
        val pw = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
        val powerSaver = pw.isPowerSaveMode
        val thermal = pw.currentThermalStatus

        // Ajustes del sistema que afectan a la fluidez
        val animScale = Settings.Global.getFloat(cr, "animator_duration_scale", 1f)
        val dontKeep = Settings.Global.getInt(cr, "always_finish_activities", 0) == 1

        // Apps
        val usageAccess = hasUsageAccess(ctx)
        val usageMap = if (usageAccess) {
            try {
                val usm = ctx.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
                usm.queryAndAggregateUsageStats(now - 30L * DAY, now)
            } catch (e: Exception) {
                emptyMap()
            }
        } else {
            emptyMap()
        }
        val ssm = ctx.getSystemService(Context.STORAGE_STATS_SERVICE) as StorageStatsManager
        val me = Process.myUserHandle()

        var cacheTotal = 0L
        var userCount = 0
        val userApps = ArrayList<AppEntry>()
        val unused = ArrayList<AppEntry>()

        for (ai in pm.getInstalledApplications(0)) {
            var size = 0L
            if (usageAccess) {
                try {
                    val st = ssm.queryStatsForPackage(StorageManager.UUID_DEFAULT, ai.packageName, me)
                    cacheTotal += st.cacheBytes
                    size = st.appBytes + st.dataBytes
                } catch (e: Exception) {
                    // Algunas apps no permiten consultar su tamaño; se ignoran.
                }
            }
            val isSystem = (ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0
            if (isSystem || ai.packageName == ctx.packageName) continue
            if (pm.getLaunchIntentForPackage(ai.packageName) == null) continue

            userCount++
            val label = pm.getApplicationLabel(ai).toString()
            val last = usageMap[ai.packageName]?.lastTimeUsed ?: 0L
            val installed = try {
                pm.getPackageInfo(ai.packageName, 0).firstInstallTime
            } catch (e: Exception) {
                0L
            }
            val ref = maxOf(last, installed)
            val entry = AppEntry(ai.packageName, label, size, ref)
            userApps.add(entry)
            if (usageAccess && ref < now - 30L * DAY && !isProtected(ai.packageName, label, userProtected)) {
                unused.add(entry)
            }
        }

        val bloat = BLOAT.mapNotNull { (pkg, name, why) ->
            try {
                val info = pm.getApplicationInfo(pkg, 0)
                if (info.enabled && !isProtected(pkg, name, userProtected)) BloatEntry(pkg, name, why) else null
            } catch (e: Exception) {
                null
            }
        }

        return Snapshot(
            takenAt = now,
            model = "${Build.MANUFACTURER} ${Build.MODEL}",
            androidVersion = "Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})",
            securityPatch = Build.VERSION.SECURITY_PATCH ?: "",
            totalRamMb = mi.totalMem / MB,
            availRamMb = mi.availMem / MB,
            storageTotalGb = totalGb,
            storageFreeGb = freeGb,
            batteryPercent = pct,
            batteryTempC = temp,
            batteryHealthGood = healthGood,
            cycleCount = cycles,
            powerSaver = powerSaver,
            thermalStatus = thermal,
            uptimeDays = SystemClock.elapsedRealtime() / DAY.toDouble(),
            animationScale = animScale,
            dontKeepActivities = dontKeep,
            userAppCount = userCount,
            usageAccess = usageAccess,
            secureSettings = hasSecureSettings(ctx),
            totalCacheMb = if (usageAccess) cacheTotal / MB else -1L,
            bigApps = userApps.sortedByDescending { it.sizeBytes }.take(5),
            unusedApps = unused.sortedByDescending { it.sizeBytes }.take(8),
            bloat = bloat
        )
    }
}
