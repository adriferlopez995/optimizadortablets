package org.centro.optimizador

import java.text.DateFormat
import java.util.Date

/** Informe en texto plano: se puede compartir y pegar en un asistente de IA para pedir un análisis más profundo. */
object Report {

    fun build(s: Snapshot?, findings: List<Finding>, base: RunData?, after: RunData?): String {
        val sb = StringBuilder()
        sb.appendLine("INFORME DE LA TABLET")
        if (s != null) {
            sb.appendLine("Modelo: ${s.model}")
            sb.appendLine("Sistema: ${s.androidVersion}, parche ${s.securityPatch}")
            sb.appendLine("RAM total: ${f1(s.totalRamMb / 1024.0)} GB (libre ahora: ${s.availRamMb} MB)")
            sb.appendLine("Almacenamiento: ${f1(s.storageFreeGb)} GB libres de ${f1(s.storageTotalGb)} GB (${f0(s.storageFreePercent)} % libre)")
            sb.appendLine("Batería: ${s.batteryPercent} %, ${f1(s.batteryTempC)} °C, ciclos: ${if (s.cycleCount >= 0) s.cycleCount.toString() else "desconocido"}")
            sb.appendLine("Días sin reiniciar: ${f1(s.uptimeDays)}")
            sb.appendLine("Apps de usuario: ${s.userAppCount}")
            if (s.totalCacheMb >= 0) sb.appendLine("Caché total: ${s.totalCacheMb} MB")
            sb.appendLine()
            sb.appendLine("PROBLEMAS DETECTADOS (por impacto)")
            if (findings.isEmpty()) sb.appendLine("Ninguno.")
            for (f in findings) {
                sb.appendLine("- [-${f.penalty}] ${f.title}")
            }
            if (s.unusedApps.isNotEmpty()) {
                sb.appendLine()
                sb.appendLine("APPS SIN USAR EN 30 DÍAS")
                for (a in s.unusedApps) sb.appendLine("- ${a.label} (${a.packageName}), ${a.sizeBytes / (1024 * 1024)} MB")
            }
            if (s.bloat.isNotEmpty()) {
                sb.appendLine()
                sb.appendLine("APPS PREINSTALADAS PRESCINDIBLES")
                for (b in s.bloat) sb.appendLine("- ${b.label} (${b.packageName})")
            }
        }
        val fmt = DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT)
        if (base != null) {
            sb.appendLine()
            sb.appendLine("MEDICIÓN INICIAL (${fmt.format(Date(base.timeMillis))}) — salud estimada ${base.score}/100")
            appendBench(sb, base.bench)
        }
        if (base != null && after != null) {
            sb.appendLine()
            sb.appendLine("MEDICIÓN POSTERIOR (${fmt.format(Date(after.timeMillis))}) — salud estimada ${after.score}/100")
            appendBench(sb, after.bench)
            val ms = Compare.metrics(base.bench, after.bench)
            val overall = Compare.overall(ms)
            sb.appendLine()
            sb.appendLine("MEJORA GLOBAL MEDIDA: ${if (overall >= 0) "+" else ""}${f1(overall)} % (margen de error aproximado ±5 %)")
            for (m in ms) {
                val d = if (m.valid) (if (m.changePercent >= 0) "+" else "") + f1(m.changePercent) + " %" else "—"
                sb.appendLine("- ${m.name}: ${f1(m.before)} → ${f1(m.after)} ${m.unit} ($d)")
            }
        }
        return sb.toString()
    }

    private fun appendBench(sb: StringBuilder, b: BenchResult) {
        sb.appendLine("CPU 1 núcleo: ${f0(b.cpuSingleMs)} ms · CPU multinúcleo: ${f0(b.cpuMultiMs)} ms · Memoria: ${f0(b.memoryMs)} ms")
        sb.appendLine("Escritura: ${f1(b.writeMbps)} MB/s · Escrituras pequeñas: ${f0(b.syncOps)} ops/s")
        sb.appendLine("Pantalla: ${f1(b.avgFps)} fps, fotograma lento p95 ${f1(b.frameP95Ms)} ms, tirones ${f1(b.jankPercent)} %")
    }
}
